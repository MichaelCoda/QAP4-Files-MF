function getTotalRecords(data) {
    return "The JSON file contains " + data.length + " records.";
  }

  function getSports(data) {
    let sports = data.map(record => record.sport);
    return "The sports in the JSON file are: " + sports.join(", ");
  }

  function getRecordByID(data, id) {
    let record = data.find(record => record.id === id);
    if (record) {
      return "Record with ID " + id + ":\n" + JSON.stringify(record, null, 2);
    } else {
      return "No record found with ID " + id + ".";
    }
  }